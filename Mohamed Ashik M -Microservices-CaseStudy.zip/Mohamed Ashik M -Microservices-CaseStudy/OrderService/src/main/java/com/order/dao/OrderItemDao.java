package com.order.dao;

import com.order.models.OrderItem;

public interface OrderItemDao {

	public boolean addItem(OrderItem item);
}
