package com.product.dao;

import java.util.List;

import com.product.models.Product;

public interface ProductDao {

	public List<Product> getproducts();
}
