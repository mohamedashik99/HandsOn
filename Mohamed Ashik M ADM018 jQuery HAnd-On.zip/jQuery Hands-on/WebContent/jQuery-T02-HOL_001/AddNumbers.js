


function add_two_number(){
    $("#result").val("");
            var a=$("#firstnumber").val();
            var b=$("#secondnumber").val();
            if(a=="" || b==""){
                $("#display").html("<font color='red'>Pls.Enter the Values</font>")
            }
            else{
            var result=parseInt(a)+parseInt(b);
           
            $("#result").val(result);
            $("#display").html("<font color='green'>"+result+"</font>");
            }
}